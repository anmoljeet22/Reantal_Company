<html>
    <head>   <link rel="stylesheet" href="css/style_index.css"><!-- comment -->
    </head>
    <body>
        <h1>Create an account</h1>
<form action="Logging.php" method="post">
    
    Email:
    <input type="email" name="user_email" placeholder="Email"required>
    Password
    <input type="password" name="password" placeholder="Password"required>

    <input type="submit" value="Submit">
</form>
        <br><!-- comment -->
        <a href="index.php">Already have an account</a>
    </body>
</html>