<html>
    
    
  <head>
    <title>Registered</title>
      <link rel="stylesheet" href="css/style_registered.css">
     <style>
      table {
        border-collapse: collapse;
        border: 1px solid black;
      }
      th, td {
        border: 1px solid black;
        padding: 5px;
      }
    </style>
  </head>
  <body>
     <a href="personal.php">Go backward</a> 
    <h1>Registered</h1>
<h2>Registration Details</h2>
<br><!-- comment -->

 <br>
<table>
  <tr>
     <th>Reference number</th>
    <th>Name</th>
    <th>Email</th>
    <th>Phone</th>
    <th>Address</th>
    <th>Postal Code</th>
    <th>Driver's License No</th>
    <th>Car Name</th>
    <th>Rental price</th>
    <th>Cancel Registration</th>
    
  </tr>
 
    
  <?php
    require_once 'connection.php';
    session_start();
    $email = $_SESSION['email'] ;
   
   $sql = "SELECT * FROM personal WHERE email= '$email'";
   $result = mysqli_query($con, $sql);
    
   
    if(mysqli_num_rows($result) > 0) {
   
      while($row = mysqli_fetch_assoc($result)) {
        $c_id =  $row['number'];
        echo "<tr>";
        echo "<td>" . $row['number'] . "</td>";
        echo "<td>" . $row['name'] . "</td>";
        echo "<td>" . $row['email'] . "</td>";
        echo "<td>" . $row['phone'] . "</td>";
        echo "<td>" . $row['address'] . "</td>";
        echo "<td>" . $row['postal_code'] . "</td>";
        echo "<td>" . $row['driver_license'] . "</td>";
        echo "<td>" . $row['car_name'] . "</td>";
        echo "<td>" . $row['rental_price'] . "</td>";
        echo "</td><td><a href=Delete.php?i=$c_id>Delete</a></td>";
     
        echo "</tr>";
      }
    } 
  ?>
  
</table>

<p>Thank you for your registration!</p>
  </body>
</html>