<!DOCTYPE html>
<html>
  <head>
    <title>Car Rental Company</title>
       <link rel="stylesheet" href="css/style_rental.css">
  </head>
  <body>
    <?php
        session_start();
        if (isset($_SESSION['isloggedin']) && $_SESSION['isloggedin'] == 1) {
            echo "<h1>Welcome Mr/Mrs ".$_SESSION['user_email']."<br></h1>";
        } else {
            header('location: index.php');
        }
    ?>
       <h1>Car Rental Company</h1>
      <table>
  <tr>
    <td>
    
  
<form action="" method="post">
    <h4>Our company services are only available in Abbotsford and Vancouver</h4>
  <label>Location:</label>
  <input type="radio" name="location" value="Abbotsford" required> Abbotsford<br>
   <input type="radio" name="location" value="Vancouver"> Vancouver<br>
  
  <br>
  <label for="pickup-date">Pickup Date:</label>
  <input type="date" name="pickupdate" required>
  
  <br>
  <label for="dropoff-date">Dropoff Date:</label>
  <input type="date" name="dropoffdate" required>
  
  <br>
  <input type="submit" name="submit" value="Search Cars">
</form>
   </td>
  </tr>
</table>

<?php
require_once 'connection.php';


function is_valid_location($location) {
    return ($location == 'Vancouver' || $location == 'Abbotsford');
}


if (isset($_POST['submit']) && isset($_POST['location']) && isset($_POST['pickupdate']) && isset($_POST['dropoffdate'])) {
    $location = $_POST['location'];
    if (!is_valid_location($location)) {
        echo "<h2>Sorry, our rental services are not available in $location.</h2>";
        exit();
    }
   
$pickupdate = $_POST['pickupdate'];
$dropoffdate = $_POST['dropoffdate'];

$date1 = strtotime($_POST['pickupdate']);
$date2 = strtotime($_POST['dropoffdate']);
$diff = $date2 - $date1;
$days = floor($diff / (60 * 60 * 24));

    $user_email = $_SESSION['user_email'];
   
    $sql_add_query = "INSERT INTO rental (location, pickupdate, dropoffdate, user_email, days) VALUES ('$location', '$pickupdate', '$dropoffdate', '$user_email', $days)";
    
    if (mysqli_query($con, $sql_add_query)) {
        $_SESSION['rental_days'] = $days;
        if ($location == 'Vancouver') {
            header('Location: vancouver.php');
        } else if ($location == 'Abbotsford') {
            header('Location: abbotsford.php');
        }
     
    
    }
}
?>

</body>
</html>
