<!DOCTYPE html>
<html>
<head>
	<title>Car Catalog</title>
        <link rel="stylesheet" href="css/style_suvs.css">
</head>
<body>
    
	<h1>Car Catalog</h1>
         
       <nav>
  <ul>
    <li><a href="cars.php">Cars</a></li>
    <li><a href="suvs.php">Suvs</a></li>
    <li><a href="trucks.php">Trucks</a></li>
  </ul>
          
</nav>
        <br><br>
	<form method="post">
		<label for="fuel_type">Filter by Fuel Type:</label>
		<select name="fuel_type" id="fuel_type">
			<option value="all">All</option>
			<option value="electric">Electric</option>
			<option value="gasoline">Gasoline</option>
		</select>
		<input type="submit" name="submit1">
	</form>
	<br>
	<?php
	require_once 'connection.php';
	session_start();
	$days = $_SESSION['rental_days'];

	$cars = array(
		array(
			"name" => "2023 Subaru Crosstrek",
			"image" => " img/Crosstrek.jpeg",
                        "description" => "The 2023 Subaru Crosstrek is a car rental option with excellent driver assistance technology, built-in navigation, and a standard Wi-Fi hotspot. It also comes equipped with an 8-speaker Harman Kardon premium sound system and offers great legroom for a comfortable ride. Overall, the 2023 Subaru Crosstrek is an excellent choice for those looking for a practical and technologically advanced car rental.",
			"price_per_day" => "$140/DAY",
                        "rental_price" => 140* $days,
			"fuel_type" => "gasoline"
		),
		array(
			"name" => "2023 Hyundai Tucson",
			"image" => "img/HyundaiTucson.jpeg",
                        "description" => "The 2023 Hyundai Tucson Plug-in Hybrid is a stylish car rental option with an appealing design. It features an 8.0-inch touchscreen with wireless Apple CarPlay and a larger 10.3-inch display, providing easy access to navigation and entertainment. Additionally, the Tucson Plug-in Hybrid comes equipped with a Bose sound system, heated seats, and blind spot detection, ensuring a safe and comfortable ride. Overall, the 2023 Hyundai Tucson Plug-in Hybrid is a great choice for those looking for a stylish and eco-friendly car rental option.",
			"price_per_day" => "$150/DAY",
                        "rental_price" => 150 * $days,
			"fuel_type" => "gasoline"
		),
                array(
			"name" => "2023 Nissan Rogue",
			"image" => "img/NissanRogue.jpeg",
                        "description" => "The 2023 Nissan Rogue is a car rental option with strong safety scores and an efficient three-cylinder engine that comes with AWD. It features a 10-speaker sound system and a 9.0-inch touchscreen with wireless Apple CarPlay, making it easy to stay connected while on the road. The Rogue also offers a wireless charging pad for added convenience. Overall, the 2023 Nissan Rogue is an excellent choice for those looking for a reliable and technologically advanced car rental option.",
			"price_per_day" => "$130/DAY",
                        "rental_price" => 130 * $days,
			"fuel_type" => "gasoline"
		),
                array(
			"name" => "Tesla Model X",
			"image" => "img/TeslaModelX.avif",
                        "description" => "The Model X is an all-electric SUV that combines luxurious features with impressive performance. With up to 360 miles of range, falcon-wing doors, and a panoramic windshield, the Model X is a stunning and innovative car rental option.",
			"price_per_day" => "$145/DAY",
                        "rental_price" => 145 * $days,
			"fuel_type" => "electric"
		),
                array(
			"name" => "2023 Subaru Forester",
			"image" => "img/subaruForester.jpeg",
                        "description" => "The 2023 Subaru Forester is a spacious and comfortable car rental option with excellent visibility and a smooth ride. It features a Harmon Kardon premium audio system, making it easy to enjoy your favorite music while on the road. Additionally, the Forester comes equipped with 4X4, ensuring a safe and reliable ride in any weather conditions. Overall, the 2023 Subaru Forester is an excellent choice for those looking for a practical and comfortable car rental option.",
			"price_per_day" => "$130/DAY",
                        "rental_price" => 130 * $days,
			"fuel_type" => "electric"
		),
                 array(
			"name" => "Ford Mustang Mach-E",
			"image" => "img/FordMustangMach-E.jpeg",
                        "description" => "The Mach-E is an all-electric SUV that combines the iconic style of the Mustang with the latest EV technology. With up to 300 miles of range, a spacious interior, and advanced safety features, the Mach-E is a stylish and practical car rental option.",
			"price_per_day" => "$150/DAY",
                        "rental_price" => 150 * $days,
			"fuel_type" => "electric"
		),
                
                
	);

if(isset($_POST['submit1'])){
             
$filter = $_POST["fuel_type"];
$filtered_cars = array();
foreach ($cars as $car) {
if ($filter == "all") {
$filtered_cars[] = $car;
} elseif ($filter =="electric" && $car["fuel_type"] == "electric") {
$filtered_cars[] = $car;
} elseif ($filter =="gasoline" && $car["fuel_type"] == "gasoline") {
$filtered_cars[] = $car;
}
}
$cars = $filtered_cars;
}
	foreach ($cars as $car) {
		echo "<div>";
		echo "<h2>" . $car["name"] . "</h2>";
		echo "<img src='" . $car["image"] . "' alt='" . $car["name"] . "'>";
                echo "<p>Description: " . $car["description"] . "</p>";
                echo "<p><strong>Per day price: " . $car["price_per_day"] . "</strong></p>";
		echo "<p><strong>Rental Price: $" . $car["rental_price"] . "</strong></p>";
		echo "<form method='post'>";
                
                //Reference W3School
                echo "<input type='hidden' name='car_name' value='" . $car["name"] . "'>";
                echo "<input type='hidden' name='rental_price' value='" . $car["rental_price"] . "'>";
                
		echo "<input type='submit' name='confirm' value='Confirm'>";
		echo "</form>";
		if(isset($_POST['confirm'])){
			        $_SESSION['car_name'] = $_POST['car_name'];
                                $_SESSION['rental_price'] = $_POST['rental_price'];
                                $_SESSION['car_type'] = $car["fuel_type"];
			$user_email = $_SESSION['user_email'];
			$sql = "INSERT INTO data (car_name, user_email, car_type, rental_price) VALUES ('{$car['name']}', '{$user_email}', '{$car['fuel_type']}', '{$car['rental_price']}')";
			if(mysqli_query($con, $sql)) {
				header("Location: personal.php");
                                break;
			}
		}
		echo "</div>";
	}
	
	?>
</body>
</html>

			
