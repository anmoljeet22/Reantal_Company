<?php
require_once 'connection.php';
session_start();
        if (isset($_SESSION['isloggedin']) && $_SESSION['isloggedin'] == 1) {
            echo "<h1>Welcome to your dashboard  ".$_SESSION['name']."<br> <br></h1>";
        } else {
            header('location: index.php');
        }
        if(isset($_GET['i']))
        {
            $c_id = $_GET['i'];
            $sql = "Delete from personal Where number = '$c_id'";
            $result = mysqli_query($con, $sql);
            
        }
        header('location:registered.php');
?>

