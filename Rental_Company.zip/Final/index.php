<html>
    <head>
    <link rel="stylesheet" href="css/style_index.css">
</head>
    <body>


<h1>Log In</h1>
<form action="Logging.php" method="post">
    
    Email:
    <input type="email" name="user_email" placeholder="Email"required>
    Password
    <input type="password" name="password" placeholder="Password"required>

    <input type="submit" value="Log In">
</form>
<br>
     <a href="createaccount.php">Create a new account</a>
</body>
</html>





