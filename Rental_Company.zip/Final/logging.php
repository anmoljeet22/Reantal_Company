<?php
session_start();
require_once 'connection.php';

if (isset($_POST['user_email']) && $_POST['user_email'] != "" && isset($_POST['password']) && $_POST['password'] != "") {
    $user_email = $_POST['user_email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE user_email = '$user_email' and password = '$password'";
    $result = mysqli_query($con, $query);
   
    if (mysqli_num_rows($result) == 0) {
        $insert = "Insert into users (user_email, password) values ('$user_email', '$password')";
        $insert_check = mysqli_query($con, $insert);
        header('location: index.php');
    } else {
        $_SESSION['isloggedin'] = 1;
        $_SESSION['user_email'] = $user_email;
        header('location: rental.php');
    }
}
?>
