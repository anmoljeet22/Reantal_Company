<!DOCTYPE html>
<html>
<head>
	<title>Car Catalog</title>
        <link rel="stylesheet" href="css/style_suvs.css">
</head>
<body>
    
	<h1>Car Catalog</h1>
              <nav>
  <ul>
    <li><a href="cars.php">Cars</a></li>
    <li><a href="suvs.php">Suvs</a></li>
    <li><a href="trucks.php">Trucks</a></li>
  </ul>
          
</nav>
        <br><br>
	<form method="post">
		<label for="fuel_type">Filter by Fuel Type:</label>
		<select name="fuel_type" id="fuel_type">
			<option value="all">All</option>
			<option value="electric">Electric</option>
			<option value="gasoline">Gasoline</option>
		</select>
		<input type="submit" name="submit1">
	</form>
	<br>
	<?php
	require_once 'connection.php';
	session_start();
	$days = $_SESSION['rental_days'];

	$cars = array(
		array(
			"name" => "2023 Ford Maverick ",
			"image" => "img/FordMaverick.jpeg",
                        "description" => "The Maverick is an efficient hybrid or turbo-four pickup truck that offers modern technology features, such as an 8.0-inch touchscreen, Wi-Fi hotspot, and Co-Pilot360 driver-assist active safet",
			"price_per_day" => "$160/DAY",
                        "rental_price" => 160 * $days,
			"fuel_type" => "electric"
		),
		array(
			"name" => "2023 Hyundai Santa Cruz",
			"image" => "img/HyundaiSantaCruz.avif",
                        "description" => "The Santa Cruz is a versatile pickup truck that comes with lane assist, a 10.3-inch gauge cluster, and a Bose sound system. It has a USB port for the second row and is powered by a V-8 engine with a turbocharger for 281 horsepower.",
			"price_per_day" => "$155/DAY",
                        "rental_price" => 155 * $days,
			"fuel_type" => "electric"
		),
                array(
			"name" => "2022 GMC Canyon",
			"image" => "img/GMCCanyon.avif",
                        "description" => "The Canyon is a midsize pickup truck with a good ride quality and a solid V-6 engine. It has a six-speaker audio system and is off-road capable, making it a great option for those who want a practical truck with some adventure features.",
			"price_per_day" => "$175/DAY",
                        "rental_price" => 175 * $days,
			"fuel_type" => "gasoline"
		),
                array(
			"name" => "2023 RAM 2500",
			"image" => "img/RAM2500.avif",
                        "description" => "The RAM 2500 Power Wagon is an off-road capable pickup truck that comes with a 17-speaker setup and a 360-degree camera system. It has a 12.3-inch digital instrument cluster and offers impressive performance both on and off the road.",
			"price_per_day" => "$180/DAY",
                        "rental_price" => 180 * $days,
			"fuel_type" => "gasoline"
		),
                array(
			"name" => "2022 Ford F-250",
			"image" => " img/FordF-250.jpeg",
                        "description" => "Heavy-duty truck that comes with impressive towing capabilities thanks to its 1,050 lb-ft of diesel torque. It features a new 12.0-inch infotainment screen that offers easy access to various features. The F-250 is equipped with a turbodiesel V-8 engine, and it also comes with advanced safety features such as lane assist and blind-spot monitoring. The truck also features heated seats, making it comfortable for long drives.",
			"price_per_day" => "$165/DAY",
                        "rental_price" => 165 * $days,
			"fuel_type" => "gasoline"
		),
                 array(
			"name" => "2022 Ford F-350",
			"image" => "img/FordF-350.jpeg",
                        "description" => "Heavy-duty truck that comes with a 10-speed automatic transmission. It features a 12.0-inch infotainment display and a 10-speaker sound system with a subwoofer, providing an immersive audio experience. The F-350 also supports Apple CarPlay, which enables easy connectivity with compatible Apple devices.",
			"price_per_day" => "$170/DAY",
                        "rental_price" => 170 * $days,
			"fuel_type" => "gasoline"
		),
                
                
	);

	if(isset($_POST['submit1'])){
             
$filter = $_POST["fuel_type"];
$filtered_cars = array();
foreach ($cars as $car) {
if ($filter == "all") {
$filtered_cars[] = $car;
} elseif ($filter == "electric" && $car["fuel_type"] == "electric") {
$filtered_cars[] = $car;
} elseif ($filter == "gasoline" && $car["fuel_type"] == "gasoline") {
$filtered_cars[] = $car;
}
}
$cars = $filtered_cars;
}
	foreach ($cars as $car) {
		echo "<div>";
		echo "<h2>" . $car["name"] . "</h2>";
		echo "<img src='" . $car["image"] . "' alt='" . $car["name"] . "'>";
                echo "<p>Description: " . $car["description"] . "</p>";
                echo "<p><strong>Per day price: " . $car["price_per_day"] . "</strong></p>";
		echo "<p><strong>Rental Price: $" . $car["rental_price"] . "</strong></p>";
		echo "<form method='post'>";
                    //Reference W3School
                echo "<input type='hidden' name='car_name' value='" . $car["name"] . "'>";
                echo "<input type='hidden' name='rental_price' value='" . $car["rental_price"] . "'>";
		echo "<input type='submit' name='confirm' value='Confirm'>";
		echo "</form>";
		if(isset($_POST['confirm'])){
			        $_SESSION['car_name'] = $_POST['car_name'];
                                $_SESSION['rental_price'] = $_POST['rental_price'];
                                $_SESSION['car_type'] = $car["fuel_type"];
			$user_email = $_SESSION['user_email'];
			$sql = "INSERT INTO data (car_name, user_email, car_type, rental_price) VALUES ('{$car['name']}', '{$user_email}', '{$car['fuel_type']}', '{$car['rental_price']}')";
			if(mysqli_query($con, $sql)) {
				header("Location: personal.php");
                                break;
			}
		}
		echo "</div>";
	}
	?>
</body>
</html>

			
