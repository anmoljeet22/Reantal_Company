
<html>
  <head>
    <title>Rental Form</title>
      <link rel="stylesheet" href="css/style_personal.css">
  </head>
  <body>
       <a href="cars.php">Go backward</a>
    <h1>Rental Form</h1>
   
    <form method="post" action="">
      <label for="name">Name:</label>
      <input type="text" id="name" name="name" required>
      <br><br>
        <label for="email">Email:</label>
  <input type="email" id="email" name="email" required>
  <br><br>
  
  <label for="phone">Phone Number:</label>
  <input type="tel" id="phone" name="phone" required>
  <br><br>
  
  <label for="address">Address:</label>
  <input type="text" id="address" name="address" required>
  <br><br>
  
  <label for="postal_code">Postal Code:</label>
  <input type="text" id="postal_code" name="postal_code" required>
  <br><br>
  
  <label for="driver_license">Driver's License No:</label>
  <input type="text" id="driver_license" name="driver_license" required>
  <br><br>

  <?php
    session_start();
    $rental_days = $_SESSION['rental_days'];
    $car_name = $_SESSION['car_name'];
    $rental_price =   $_SESSION['rental_price'];
    echo "<strong>Selected car name: " . $car_name . "</strong><br>";
    echo "<strong>Selected car price: $" . $rental_price . "</strong><br>";
    

    
  ?>
  <form action="upload.php" method="post" enctype="multipart/form-data"><strong>Please upload an image of your driving license:</strong>
  <input type="file" name="fileToUpload" id="fileToUpload">
  

  <input type="submit" name="submit" value="Submit">
</form>
    

<?php
  require_once 'connection.php';
  
  if(isset($_POST['submit'])){
  
      $name = $_POST['name'];
      $email = $_POST['email'];
      $phone = $_POST['phone'];
      $address = $_POST['address'];
      $postal_code = $_POST['postal_code'];
      $driver_license = $_POST['driver_license'];
      $car_name =  $_SESSION['car_name'];
      $rental_price =   $_SESSION['rental_price'];
      $_SESSION['email'] = $email;
   

      $sql = "INSERT INTO personal (name, email, phone, address, postal_code, driver_license, car_name, rental_price) VALUES ('$name', '$email', '$phone', '$address', '$postal_code', '$driver_license', '$car_name','$rental_price')";


      if(mysqli_query($con, $sql)) {
           header('Location: registered.php');
      }
  }
 

?>

  </body>
</html>
