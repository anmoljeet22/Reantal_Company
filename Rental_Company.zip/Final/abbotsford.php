<!DOCTYPE html>
<html>
  <head>
    <title>Car Details</title>
    <link rel="stylesheet" href="css/style_abbotsford.css">
  </head>
  <body>
    <div class="container">
      <a href="rental.php">Go backward</a>
      <form action="" method="post">
        <h2>Car Details</h2>
        <p>Type:</p>
        <div class="checkboxes">
          <input type="checkbox" name="type" value="cars" >
          <label for="cars">Cars</label>
          <input type="checkbox" name="type" value="suvs">
          <label for="suvs">SUVs</label>
          <input type="checkbox" name="type" value="trucks">
          <label for="trucks">Trucks</label>
        </div>
        <input type="submit" value="Click to confirm">
      </form>
    </div>
    <footer>
      <div class="container">
        <h2>Start your journey with us today</h2>
        <br><br>
        <div class="image-container">
          <a href="cars.php"><img src="img/logo1.jpeg" class="footer-image"></a>
          <a href="suvs.php"><img src="img/logo2.jpeg" class="footer-image"></a>
          <a href="trucks.php"><img src="img/logo3.jpeg" class="footer-image"></a>
        </div>
      </div>
    </footer>
    <?php
    if (isset($_POST['type']) && $_POST['type'] != "") {
        $type = $_POST['type'];
        switch ($type) {
            case 'cars':
                header('Location: cars.php');
                exit();
            case 'suvs':
                header('Location: suvs.php');
                exit();
            case 'trucks':
                header('Location: trucks.php');
                exit();
            default:
             
                break;
        }
    }
    ?>
  </body>
</html>
