<!DOCTYPE html>
<html>
<head>
	<title>Car Catalog</title>
        <link rel="stylesheet" href="css/style_suvs.css">
</head>
<body>
   
	<h1>Car Catalog</h1>
       
	      <nav>
  <ul>
    <li><a href="cars.php">Cars</a></li>
    <li><a href="suvs.php">Suvs</a></li>
    <li><a href="trucks.php">Trucks</a></li>
  </ul>
          
</nav>
        <br><br>
	<form method="post">
		<label for="fuel_type">Filter by Fuel Type:</label>
		<select name="fuel_type" id="fuel_type">
			<option value="all">All</option>
			<option value="electric">Electric</option>
			<option value="gasoline">Gasoline</option>
		</select>
		<input type="submit" name = "submit1"  >
	</form>
	<br>
	<?php
	require_once 'connection.php';
	session_start();
	$days = $_SESSION['rental_days'];

	$cars = array(
		array(
			"name" => "2023 Kia Rio",
			"image" => "img/rio1.avif",
                        "description" => "The 2023 Kia Rio LX Sedan is a fuel-efficient car with strong features, good ride quality, and heated front seats. It also has blind spot detection and supports Android Auto and Apple CarPlay. It's an excellent choice for an affordable and reliable car rental.",
		       "price_per_day" => "$70/DAY",
                        "rental_price" => 70 * $days,
			"fuel_type" => "gasoline"
		),
		array(
			"name" => "2023 Honda Civic",
			"image" => "img/civic1.jpeg",
                        "description" => "The 2023 Honda Civic boasts many safety features, including electronic brakes, advanced front airbags, and blind spot detection. With keyless entry and support for Apple CarPlay and Android Auto, it's easy to stay connected while driving. It's a great option for those who prioritize safety and convenience.",
		       "price_per_day" => "$110/DAY",
                       "rental_price" => 110 * $days,
			"fuel_type" => "gasoline"
		),
                array(
			"name" => "2023 Hyundai Elantra",
			"image" => "img/elantra.avif",
                        "description" => "The 2023 Hyundai Elantra is an affordable and fuel-efficient car with eye-catching styling. It has impressive fuel economy and comes equipped with automatic braking and a blind spot mirror for added safety. The Elantra also supports Android Auto and Apple CarPlay, making it easy to stay connected on the go. Overall, the 2023 Hyundai Elantra is an excellent choice for those looking for a stylish and economical car rental.",
			"price_per_day" => "$110/DAY",
                        "rental_price" => 110 * $days,
			"fuel_type" => "gasoline"
		),
                array(
			"name" => "Genesis G80",
			"image" => "img/genesis1.jpeg",
                        "description" => "The Genesis G80 Electric is a luxurious car rental option with a quiet cabin and effortless acceleration. It features a stunning interior with top-end luxury features, including a 21-speaker Lexicon surround sound system and a head-up display. Additionally, the G80 Electric comes equipped with a 360-degree camera system, providing maximum visibility for drivers. Overall, the Genesis G80 Electric is an excellent choice for those looking for a premium and comfortable car rental experience.",
	              "price_per_day" => "$150/DAY",
                       "rental_price" => 150 * $days,
			"fuel_type" => "electric"
		),
                array(
			"name" => "2023 BMW iX",
			"image" => "img/BMWIX.avif",
                        "description" => "The 2023 BMW iX is an all-electric car with a range of over 300 miles on a single charge. It features gesture control and comes with luxury packages that include multi-functional seats and soft-close automatic doors. With its advanced technology and eco-friendly features, the iX is a great choice for those who prioritize luxury and sustainability. Overall, the 2023 BMW iX is an excellent option for those looking for a high-end, environmentally conscious car rental.",
			"price_per_day" => "$120/DAY",
                        "rental_price" => 120 * $days,
			"fuel_type" => "electric"
		),
                 array(
			"name" => "Tesla Model S",
			"image" => "img/TeslaModelS.avif",
                        "description" => "The Tesla Model S is a fully electric car with a range of 637 kilometers on a full charge. It has a top speed of 322 km/h and offers a 360-degree view for maximum visibility. The Model S also features AutoPilot, an advanced driving assistance system, and auto parking, making it a convenient and technologically advanced car rental option. Overall, the Tesla Model S is an excellent choice for those looking for a high-performance, eco-friendly, and tech-savvy car rental.",
			"price_per_day" => "$120/DAY",
                        "rental_price" => 120 * $days,
			"fuel_type" => "electric"
		),
	);

	if(isset($_POST['submit1'])){
             
$filter = $_POST["fuel_type"];
$filtered_cars = array();
foreach ($cars as $car) {
if ($filter == "all") {
$filtered_cars[] = $car;
} elseif ($filter == "electric" && $car["fuel_type"] == "electric") {
$filtered_cars[] = $car;
} elseif ($filter == "gasoline" && $car["fuel_type"] == "gasoline") {
$filtered_cars[] = $car;
}
}
$cars = $filtered_cars;

}


	foreach ($cars as $car) {
		echo "<div>";
		echo "<h2>" . $car["name"] . "</h2>";
		echo "<img src='" . $car["image"] . "' alt='" . $car["name"] . "'>";
                echo "<p>Description: " . $car["description"] . "</p>";
                echo "<p><strong>Per day price: " . $car["price_per_day"] . "</strong></p>";
		echo "<p><strong>Rental Price: $" . $car["rental_price"] . "</strong></p>";
		echo "<form method='post'>";
                // Reference W3School
                echo "<input type='hidden' name='car_name' value='" . $car["name"] . "'>";
                echo "<input type='hidden' name='rental_price' value='" . $car["rental_price"] . "'>";
		echo "<input type='submit' name='confirm' value='Confirm'>";
		echo "</form>";
		if(isset($_POST['confirm'])){
			        $_SESSION['car_name'] = $_POST['car_name'];
                                $_SESSION['rental_price'] = $_POST['rental_price'];
                                $_SESSION['car_type'] = $car["fuel_type"];
			$user_email = $_SESSION['user_email'];
			$sql = "INSERT INTO data (car_name, user_email, car_type, rental_price) VALUES ('{$car['name']}', '{$user_email}', '{$car['fuel_type']}', '{$car['rental_price']}')";
			if(mysqli_query($con, $sql)) {
				header("Location: personal.php");
                                break;
			}
		}
		echo "</div>";
	}
	
	?>
</body>
</html>

			
